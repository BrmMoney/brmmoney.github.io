const fanUrl = document.getElementById("fanUrl");
const saved = localStorage.getItem("brmFanUrl");
if (saved) fanUrl.value = saved;

document.querySelectorAll("[data-requires-url]").forEach(btn => {
  btn.addEventListener("click", (event) => {
    const value = fanUrl.value.trim();
    if (!value) {
      event.preventDefault();
      fanUrl.focus();
      fanUrl.setCustomValidity("Enter your URL first.");
      fanUrl.reportValidity();
      return;
    }
    fanUrl.setCustomValidity("");
    localStorage.setItem("brmFanUrl", value);
  });
});

fanUrl.addEventListener("input", () => {
  fanUrl.setCustomValidity("");
  if (fanUrl.value.trim()) localStorage.setItem("brmFanUrl", fanUrl.value.trim());
});
