# BrmMoney — Free Artist Promo Page

This folder is a ready-to-host static artist page.

## Included
- `index.html` — full artist landing page
- `styles.css` — 2030 / edgy / up-and-coming visual style
- `script.js` — URL field + local browser storage
- `brmmoney-logo.jpg` — your supplied artwork
- `brmmoney_promo_ad.png` — a ready-made promotional ad image

## Important: music delivery URL
The page includes a fan URL field, but a browser cannot safely take an MP3 and upload it directly into an arbitrary URL a visitor types. That requires a server endpoint designed to receive uploads.

For real downloadable music:
1. Put your MP3 files on a host you control.
2. Replace the YouTube links in `index.html` with direct MP3 URLs.
3. Change the button labels if you want "DOWNLOAD" instead of "WATCH NOW".

The current page keeps the visitor's URL only in their own browser and then opens the selected music link.

## Free hosting
- GitHub Pages can host a static site from a public repository with GitHub Free.
- Cloudflare Pages has a free plan for static assets.
- Netlify currently offers a $0 Free plan with usage limits.

No paid domain is required; the free host gives you a web address.

## Customize
Search `YOUR-EMAIL@example.com` in `index.html` and replace it with your booking email.

Replace the YouTube URLs with your official streaming/download links as you release more music.
